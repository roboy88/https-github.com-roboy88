# Roman Dobczansky · Online CV

This repository hosts my single-page online CV. It is designed to be deployed with **GitHub Pages**.

- **Live site (after publishing):** `https://roboy88.github.io/`
- **Source:** `index.html`

## Local development
Just open `index.html` in your browser. No build step.

## Publish on GitHub Pages
1. Create a new repo named **`roboy88.github.io`**.
2. Upload `index.html` (from this repo).
3. In **Settings → Pages**, ensure the source is **main** branch, **/ (root)**.
4. Your site will be live at `https://roboy88.github.io/` in a minute.

---

Need to update content? Edit the text in `index.html` directly.
